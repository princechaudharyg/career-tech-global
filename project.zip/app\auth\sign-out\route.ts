import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();

  await supabase.auth.signOut({ scope: "local" });

  return NextResponse.redirect(
    new URL("/auth/sign-in", request.url),
    { status: 303 }
  );
}